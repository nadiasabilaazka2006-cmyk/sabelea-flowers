<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Sabiléa Flowers - Kontak</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <header>
        <div class="logo">Sabiléa Flowers</div>
        <nav>
            <a href="index.php">Beranda</a>
            <a href="tentang.php">Tentang</a>
            <a href="produk.php">Produk</a>
            <a href="pesan.php">Pesan</a>
            <a href="kontak.php" class="active">Kontak</a>
        </nav>
    </header>

    <div class="container">
        <h2>Kontak Kami</h2>
        <p>Punya pertanyaan seputar stok buket atau kustomisasi khusus? Kami siap membantu.</p>

        <div style="display: flex; gap: 40px; margin-top: 30px;">
            <div style="flex: 1;">
                <h3 style="color: #8a3b52;">Hubungi Kami</h3>
                <p><strong>WhatsApp:</strong> 0812-3456-7890</p>
                <p><strong>Email:</strong> admin@sabeleaflowers.com</p>
                <p><strong>Alamat:</strong> Jl. Ketintang No. 15, Surabaya</p>

                <h3 style="margin-top: 25px; color: #8a3b52;">Jam Layanan</h3>
                <table>
                    <tr><th>Hari</th><th>Jam</th></tr>
                    <tr><td>Senin s.d. Jumat</td><td>09.00 - 20.00</td></tr>
                    <tr><td>Sabtu</td><td>09.00 - 17.00</td></tr>
                    <tr><td>Minggu</td><td>Hanya Chat WhatsApp</td></tr>
                </table>
            </div>
            
            <div style="flex: 1;">
                <h3 style="color: #8a3b52;">Kirim Pesan Cepat</h3>
                <form>
                    <label>Nama</label>
                    <input type="text" placeholder="Nama Anda">
                    <label>Email</label>
                    <input type="email" placeholder="Email Anda">
                    <label>Pesan</label>
                    <textarea rows="4" style="width: 100%; padding: 10px; margin-top: 5px; border: 1px solid #d1b3bd; border-radius: 6px;" placeholder="Tulis pesan..."></textarea>
                    <button type="button" style="margin-top: 15px;">Kirim Pesan</button>
                </form>
            </div>
        </div>
    </div>

    <footer>
        <div><h3>Sabiléa Flowers</h3></div>
        <div><h4>Halaman</h4><a href="index.php">Beranda</a><a href="kontak.php">Kontak</a></div>
    </footer>
    <div class="copyright">&copy; 2026 Sabiléa Flowers.</div>

</body>
</html>