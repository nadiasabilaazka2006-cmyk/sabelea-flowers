<?php
$counterFile = "counter.txt";
if (!file_exists($counterFile)) { file_put_contents($counterFile, "0"); }
$currentViews = (int)file_get_contents($counterFile);
$currentViews++;
file_put_contents($counterFile, (string)$currentViews);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Sabiléa Flowers - Beranda</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <header>
        <div class="logo">Sabiléa Flowers</div>
        <nav>
            <a href="index.php" class="active">Beranda</a>
            <a href="tentang.php">Tentang</a>
            <a href="produk.php">Produk</a>
            <a href="pesan.php">Pesan</a>
            <a href="kontak.php">Kontak</a>
        </nav>
    </header>

    <div class="hero">
        <div class="hero-text">
            <h1>Buket segar, rangkaian indah, spesial untuk orang tercinta.</h1>
            <p>Sabiléa Flowers memilih bunga terbaik setiap hari untuk momen wisuda, ulang tahun, dan perayaan spesial Anda.</p>
            <a href="produk.php" class="btn" style="background-color: #ffffff; color: #8a3b52;">Lihat Katalog</a>
        </div>
        <!-- Gambar buket bunga segar -->
        <img src="https://images.unsplash.com/photo-1526047932273-341f2a7631f9?auto=format&fit=crop&w=600&q=80" alt="Buket Bunga Sabiléa">
    </div>

    <div class="container">
        <section style="display: flex; gap: 30px;">
            <div style="flex: 1;">
                <h2>Kenapa beli di Sabiléa Flowers?</h2>
                <ul style="padding-left: 20px; color: #666;">
                    <li>Bunga dijamin segar dan dikirim dengan penanganan khusus.</li>
                    <li>Foto dan video konfirmasi diberikan sebelum dikirim ke penerima.</li>
                    <li>Packing menggunakan kertas premium dan pengaman yang aman.</li>
                    <li>Diskon 10% untuk pembelian minimal 3 buket atau lebih.</li>
                </ul>
            </div>
            <div style="flex: 1;">
                <h2>Cara memesan</h2>
                <ol style="padding-left: 20px; color: #666;">
                    <li>Pilih buket di halaman <strong>Produk</strong>.</li>
                    <li>Isi formulir pemesanan di halaman <strong>Pesan</strong>.</li>
                    <li>Lakukan konfirmasi atau pembayaran sesuai petunjuk sistem.</li>
                    <li>Kirim buket dan buat hari spesial mereka lebih berkesan!</li>
                </ol>
            </div>
        </section>
    </div>

    <footer>
        <div>
            <h3>Sabiléa Flowers</h3>
            <p>Buket bunga segar, dikirim dengan penuh cinta.</p>
        </div>
        <div>
            <h4>Halaman</h4>
            <ul>
                <li><a href="index.php">Beranda</a></li>
                <li><a href="tentang.php">Tentang</a></li>
                <li><a href="produk.php">Produk</a></li>
                <li><a href="pesan.php">Pesan</a></li>
                <li><a href="kontak.php">Kontak</a></li>
            </ul>
        </div>
        <div>
            <h4>Statistik</h4>
            <p>Total Page Views: <strong><?php echo $currentViews; ?></strong></p>
        </div>
    </footer>
    <div class="copyright">&copy; 2026 Sabiléa Flowers. Seluruh hak cipta dilindungi.</div>

</body>
</html>