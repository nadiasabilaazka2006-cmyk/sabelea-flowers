<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Sabiléa Flowers - Tentang Kami</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <header>
        <div class="logo">Sabiléa Flowers</div>
        <nav>
            <a href="index.php">Beranda</a>
            <a href="tentang.php" class="active">Tentang</a>
            <a href="produk.php">Produk</a>
            <a href="pesan.php">Pesan</a>
            <a href="kontak.php">Kontak</a>
        </nav>
    </header>

    <div class="container">
        <h2>Tentang Sabiléa Flowers</h2>
        <p>Toko bunga yang dimulai dari hobi merangkai dan tumbuh karena kepercayaan pelanggan setia kami.</p>

        <h3 style="margin-top: 30px; color: #8a3b52;">Cerita Kami</h3>
        <p>Sabiléa Flowers berawal dari keinginan menghadirkan buket berkualitas tinggi dengan harga terjangkau bagi mahasiswa dan masyarakat umum. Setiap rangkaian dikerjakan oleh florist berpengalaman.</p>

        <h3 style="margin-top: 20px; color: #8a3b52;">Yang Kami Pegang:</h3>
        <ul style="padding-left: 20px; color: #666;">
            <li>Jujur soal kondisi dan kesegaran bunga.</li>
            <li>Foto produk sesuai dengan aslinya.</li>
            <li>Siap membantu konsultasi pemilihan buket sesuai bujet.</li>
        </ul>
    </div>

    <footer>
        <div><h3>Sabiléa Flowers</h3><p>Buket bunga segar pilihan.</p></div>
        <div><h4>Halaman</h4><a href="index.php">Beranda</a><a href="tentang.php">Tentang</a></div>
        <div><h4>Statistik</h4><p>Florist Profesional</p></div>
    </footer>
    <div class="copyright">&copy; 2026 Sabiléa Flowers.</div>

</body>
</html>