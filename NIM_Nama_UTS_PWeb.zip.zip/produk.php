<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Sabiléa Flowers - Produk</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <header>
        <div class="logo">Sabiléa Flowers</div>
        <nav>
            <a href="index.php">Beranda</a>
            <a href="tentang.php">Tentang</a>
            <a href="produk.php" class="active">Produk</a>
            <a href="pesan.php">Pesan</a>
            <a href="kontak.php">Kontak</a>
        </nav>
    </header>

    <div class="container">
        <h2>Katalog Buket Bunga</h2>
        <p>Pilih buket bunga favoritmu dan pesan langsung lewat formulir online.</p>

        <div class="product-grid">
            <div class="product-card">
                <img src="https://images.unsplash.com/photo-1561181286-d3fee7d55364?auto=format&fit=crop&w=400&q=80" alt="Rose">
                <h3>Classic Rose Bouquet</h3>
                <p class="price">Rp150.000</p>
                <a href="pesan.php" class="btn">Pesan Buket Ini</a>
            </div>
            <div class="product-card">
                <img src="https://images.unsplash.com/photo-1526047932273-341f2a7631f9?auto=format&fit=crop&w=400&q=80" alt="Tulip">
                <h3>Luxury Tulip Box</h3>
                <p class="price">Rp300.000</p>
                <a href="pesan.php" class="btn">Pesan Buket Ini</a>
            </div>
            <div class="product-card">
                <img src="https://tokyoflora.com/wp-content/uploads/2019/01/pink-mix-arrangement2.jpg" alt="Grand Mixed Bloom">
                <h3>Grand Mixed Bloom</h3>
                <p class="price">Rp500.000</p>
                <a href="pesan.php" class="btn">Pesan Buket Ini</a>
            </div>
        </div>

        <h2 style="margin-top: 40px;">Daftar Harga Lengkap</h2>
        <table>
            <tr>
                <th>Nama Produk / Paket</th>
                <th>Kategori</th>
                <th>Harga</th>
            </tr>
            <tr>
                <td>Classic Rose Bouquet</td>
                <td>Buket Mawar</td>
                <td>Rp150.000</td>
            </tr>
            <tr>
                <td>Luxury Tulip Box</td>
                <td>Kotak Tulip</td>
                <td>Rp300.000</td>
            </tr>
            <tr>
                <td>Grand Mixed Bloom</td>
                <td>Buket Besar Campur</td>
                <td>Rp500.000</td>
            </tr>
            <tr>
                <td>Custom Greeting Card</td>
                <td>Add-on Tambahan</td>
                <td>Rp25.000</td>
            </tr>
            <tr>
                <td>Fairy Lights Decoration</td>
                <td>Add-on Tambahan</td>
                <td>Rp50.000</td>
            </tr>
        </table>
    </div>

    <footer>
        <div><h3>Sabiléa Flowers</h3></div>
        <div><h4>Halaman</h4><a href="index.php">Beranda</a><a href="produk.php">Produk</a></div>
    </footer>
    <div class="copyright">&copy; 2026 Sabiléa Flowers.</div>

</body>
</html>