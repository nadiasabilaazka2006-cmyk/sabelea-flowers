<?php
$isSubmitted = false;
$errors = [];
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $customerName = trim($_POST["customer_name"] ?? "");
    $whatsapp = trim($_POST["whatsapp"] ?? "");
    $selectedPackage = $_POST["service_package"] ?? "";
    $selectedAddOns = $_POST["add_ons"] ?? [];
    
    $packagePrices = [
        "rose_bouquet" => 150000,
        "tulip_box" => 300000,
        "grand_bloom" => 500000
    ];
    $packageLabels = [
        "rose_bouquet" => "Classic Rose Bouquet (Rp150.000)",
        "tulip_box" => "Luxury Tulip Box (Rp300.000)",
        "grand_bloom" => "Grand Mixed Bloom (Rp500.000)"
    ];
    
    if ($customerName === "") { $errors[] = "Nama lengkap wajib diisi."; }
    if ($whatsapp === "") { $errors[] = "Nomor WhatsApp wajib diisi."; }
    if (!array_key_exists($selectedPackage, $packagePrices)) { $errors[] = "Pilih paket buket yang valid."; }
    
    if (count($errors) === 0) {
        $isSubmitted = true;
        $packageName = $packageLabels[$selectedPackage];
        $totalHarga = $packagePrices[$selectedPackage];
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Sabiléa Flowers - Pesan Buket</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <header>
        <div class="logo">Sabiléa Flowers</div>
        <nav>
            <a href="index.php">Beranda</a>
            <a href="tentang.php">Tentang</a>
            <a href="produk.php">Produk</a>
            <a href="pesan.php" class="active">Pesan</a>
            <a href="kontak.php">Kontak</a>
        </nav>
    </header>

    <div class="container">
        <h2>Pesan Buket Bunga</h2>
        <p>Isi formulir untuk melihat total biaya, lalu lanjutkan pesanan.</p>

        <?php if ($isSubmitted) { ?>
            <div style="background: #eef9ed; border: 1px solid #b2d8b2; padding: 20px; border-radius: 8px; margin-top: 20px;">
                <h3 style="color: #2e7d32;">Pesanan Berhasil Diproses!</h3>
                <p><strong>Nama:</strong> <?php echo htmlspecialchars($customerName); ?></p>
                <p><strong>WhatsApp:</strong> <?php echo htmlspecialchars($whatsapp); ?></p>
                <p><strong>Paket Dipilih:</strong> <?php echo htmlspecialchars($packageName); ?></p>
                <p><strong>Estimasi Total:</strong> Rp<?php echo number_format($totalHarga, 0, ',', '.'); ?></p>
                <p style="margin-top: 15px; color: #555;">Silakan konfirmasi pesanan Anda melalui tombol WhatsApp toko kami.</p>
                <a href="pesan.php" class="btn" style="margin-top: 10px;">Buat Pesanan Baru</a>
            </div>
        <?php } else { ?>
            <?php if (count($errors) > 0) { ?>
                <div style="background: #fde8e8; border: 1px solid #f8b4b4; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                    <ul style="color: #c53030; padding-left: 20px;">
                        <?php foreach ($errors as $err) { echo "<li>$err</li>"; } ?>
                    </ul>
                </div>
            <?php } ?>

            <form action="pesan.php" method="post">
                <label for="customer_name">Nama Lengkap</label>
                <input type="text" id="customer_name" name="customer_name" required placeholder="Masukkan nama Anda">

                <label for="whatsapp">Nomor WhatsApp</label>
                <input type="text" id="whatsapp" name="whatsapp" required placeholder="08123456789">

                <label for="service_package">Pilih Paket Buket</label>
                <select id="service_package" name="service_package" required>
                    <option value="">-- Pilih Paket --</option>
                    <option value="rose_bouquet">Classic Rose Bouquet - Rp150.000</option>
                    <option value="tulip_box">Luxury Tulip Box - Rp300.000</option>
                    <option value="grand_bloom">Grand Mixed Bloom - Rp500.000</option>
                </select>

                <button type="submit" style="margin-top: 20px;">Proses Pesanan</button>
            </form>
        <?php } ?>
    </div>

    <footer>
        <div><h3>Sabiléa Flowers</h3></div>
        <div><h4>Halaman</h4><a href="index.php">Beranda</a><a href="pesan.php">Pesan</a></div>
    </footer>
    <div class="copyright">&copy; 2026 Sabiléa Flowers.</div>

</body>
</html>