<?php
date_default_timezone_set("Asia/Jakarta");

// Validasi akses halaman (harus dari POST form)
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: index.php");
    exit;
}

$customerName = trim($_POST["customer_name"] ?? "");
$email = trim($_POST["email"] ?? "");
$selectedPackage = $_POST["service_package"] ?? "";
$selectedAddOns = $_POST["add_ons"] ?? [];
$agreementAccepted = isset($_POST["agree"]);

if (!is_array($selectedAddOns)) {
    $selectedAddOns = [];
}

// Data harga dan label resmi Sabiléa Flowers
$packagePrices = [
    "rose_bouquet" => 150000,
    "tulip_box" => 300000,
    "grand_bloom" => 500000
];

$packageLabels = [
    "rose_bouquet" => "Classic Rose Bouquet",
    "tulip_box" => "Luxury Tulip Box",
    "grand_bloom" => "Grand Mixed Bloom"
];

$addOnPrices = [
    "greeting_card" => 25000,
    "fairy_lights" => 50000,
    "chocolate_box" => 75000
];

$addOnLabels = [
    "greeting_card" => "Custom Greeting Card",
    "fairy_lights" => "Fairy Lights Decoration",
    "chocolate_box" => "Mini Chocolate Box"
];

$errors = [];

// Server-side validation
if ($customerName === "") {
    $errors[] = "Customer name is required.";
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = "Enter a valid email address.";
}

if (!array_key_exists($selectedPackage, $packagePrices)) {
    $errors[] = "Select a valid service package.";
}

foreach ($selectedAddOns as $addon) {
    if (!array_key_exists($addon, $addOnPrices)) {
        $errors[] = "An invalid add-on was submitted.";
        break;
    }
}

if (!$agreementAccepted) {
    $errors[] = "You must confirm the order information.";
}

// Perhitungan Harga menggunakan Operator & Variabel PHP
$packagePrice = 0;
$addOnTotal = 0;
$grandTotal = 0;

if (count($errors) === 0) {
    $packagePrice = $packagePrices[$selectedPackage];
    foreach ($selectedAddOns as $addon) {
        $addOnTotal += $addOnPrices[$addon];
    }
    $grandTotal = $packagePrice + $addOnTotal;
    
    $orderDate = date("d F Y");
    $orderTime = date("H:i:s");
}

function rupiah($value) {
    return "Rp" . number_format($value, 0, ",", ".");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sabiléa Flowers - Order Summary</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <?php if (count($errors) > 0) { ?>
            <h1 style="color: #d9534f;">Order Cannot Be Processed</h1>
            <ul>
                <?php foreach ($errors as $error) { ?>
                    <li><?php echo htmlspecialchars($error); ?></li>
                <?php } ?>
            </ul>
            <p><a href="index.php">Return to Order Form</a></p>
        <?php } else { ?>
            <h1>Sabiléa Flowers - Order Summary</h1>
            <p>Order date: <?php echo $orderDate; ?></p>
            <p>Order time: <?php echo $orderTime; ?> WIB</p>
            <table>
                <tr>
                    <th>Customer Name</th>
                    <td><?php echo htmlspecialchars($customerName); ?></td>
                </tr>
                <tr>
                    <th>Email</th>
                    <td><?php echo htmlspecialchars($email); ?></td>
                </tr>
                <tr>
                    <th>Selected Package</th>
                    <td>
                        <?php echo htmlspecialchars($packageLabels[$selectedPackage]); ?> 
                        (<?php echo rupiah($packagePrice); ?>)
                    </td>
                </tr>
                <tr>
                    <th>Additional Services</th>
                    <td>
                        <?php if (count($selectedAddOns) === 0) { ?>
                            None
                        <?php } else { ?>
                            <ul>
                                <?php foreach ($selectedAddOns as $addon) { ?>
                                    <li>
                                        <?php echo htmlspecialchars($addOnLabels[$addon]); ?> 
                                        - <?php echo rupiah($addOnPrices[$addon]); ?>
                                    </li>
                                <?php } ?>
                            </ul>
                        <?php } ?>
                    </td>
                </tr>
                <tr>
                    <th>Add-on Total</th>
                    <td><?php echo rupiah($addOnTotal); ?></td>
                </tr>
                <tr>
                    <th>Grand Total</th>
                    <td><strong><?php echo rupiah($grandTotal); ?></strong></td>
                </tr>
            </table>
            <p><a href="index.php">&larr; Create Another Order</a></p>
        <?php } ?>
    </div>
</body>
</html>